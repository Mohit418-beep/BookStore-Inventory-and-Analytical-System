#!/usr/bin/env python
# coding: utf-8

# In[ ]:




import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

sns.set(style="whitegrid")
plt.rcParams["figure.figsize"] = (10, 5)


class Bookstore:

    def __init__(self, inventory_file="inventory.csv", sales_file="sales.csv"):
        self.inventory_file = inventory_file
        self.sales_file = sales_file

        # Load or create files
        self.load_data()


    def load_data(self):
        """Load inventory and sales CSV files safely."""

        # Load inventory
        try:
            self.inventory_df = pd.read_csv(self.inventory_file)
        except:
            print("⚠ inventory.csv not found — creating new file.")
            self.inventory_df = pd.DataFrame(
                columns=["Title", "Author", "Genre", "Price", "Quantity"]
            )
            self.inventory_df.to_csv(self.inventory_file, index=False)

        # Load sales
        try:
            self.sales_df = pd.read_csv(self.sales_file)
        except:
            print("⚠ sales.csv not found — creating new file.")
            self.sales_df = pd.DataFrame(
                columns=["Date", "Title", "Quantity Sold", "Total Revenue"]
            )
            self.sales_df.to_csv(self.sales_file, index=False)

    # ---------------------------------------------
    # INVENTORY MANAGEMENT
    # ---------------------------------------------
    def add_book(self, title, author, genre, price, quantity):

        # Control structure validation
        if price <= 0 or quantity <= 0:
            print(" Price and Quantity must be positive.")
            return

        new_book = {
            "Title": title,
            "Author": author,
            "Genre": genre,
            "Price": price,
            "Quantity": quantity,
        }

        self.inventory_df.loc[len(self.inventory_df)] = new_book
        self.save_inventory()
        print(f" Book '{title}' added successfully!")

    def update_inventory(self, title, quantity):
        if quantity < 0:
            print(" Quantity cannot be negative.")
            return

        if title in self.inventory_df['Title'].values:
            idx = self.inventory_df[self.inventory_df['Title'] == title].index[0]
            self.inventory_df.at[idx, 'Quantity'] = quantity
            self.save_inventory()
            print(f" Inventory updated for: {title}")
        else:
            print(" Book not found.")

    def record_sale(self, title, qty_sold):

        if qty_sold <= 0:
            print(" Sold quantity must be positive.")
            return

        if title not in self.inventory_df['Title'].values:
            print(" Book not available in inventory.")
            return

        # Check stock
        idx = self.inventory_df[self.inventory_df['Title'] == title].index[0]
        stock = self.inventory_df.at[idx, 'Quantity']

        if qty_sold > stock:
            print(" Not enough stock available.")
            return

        # Update inventory
        price = self.inventory_df.at[idx, 'Price']
        total_revenue = price * qty_sold

        self.inventory_df.at[idx, 'Quantity'] = stock - qty_sold
        self.save_inventory()

        # Add to sales file
        sale = {
            "Date": datetime.today().strftime("%Y-%m-%d"),
            "Title": title,
            "Quantity Sold": qty_sold,
            "Total Revenue": total_revenue
        }

        self.sales_df.loc[len(self.sales_df)] = sale
        self.save_sales()

        print(f" Sale recorded: {title} ({qty_sold} copies)")

    # ---------------------------------------------
    # SAVE DATA
    # ---------------------------------------------
    def save_inventory(self):
        self.inventory_df.to_csv(self.inventory_file, index=False)

    def save_sales(self):
        self.sales_df.to_csv(self.sales_file, index=False)

    # ---------------------------------------------
    # REPORT & ANALYSIS
    # ---------------------------------------------
    def generate_report(self):

        print("\n==========  BOOKSTORE REPORT ==========")

        total_books = len(self.inventory_df)
        total_sales = self.sales_df["Quantity Sold"].sum()
        revenue = self.sales_df["Total Revenue"].sum()

        print(f"Total Books in Inventory: {total_books}")
        print(f"Total Units Sold: {total_sales}")
        print(f"Total Revenue: ₹{revenue}")

        print("\n--- Top Selling Books ---")
        if not self.sales_df.empty:
            print(self.sales_df.groupby("Title")["Quantity Sold"]
                  .sum()
                  .sort_values(ascending=False)
                  .head())
        else:
            print("No sales data available.")

    # ---------------------------------------------
    # VISUALIZATIONS
    # ---------------------------------------------
    def visualize_sales_by_genre(self):
        merged = pd.merge(self.sales_df, self.inventory_df, on="Title")
        genre_sales = merged.groupby("Genre")["Quantity Sold"].sum()

        genre_sales.plot(kind="bar")
        plt.title("Sales by Genre")
        plt.xlabel("Genre")
        plt.ylabel("Units Sold")
        plt.show()

    def visualize_monthly_sales(self):
        self.sales_df['Date'] = pd.to_datetime(self.sales_df['Date'])
        monthly = self.sales_df.groupby(self.sales_df['Date'].dt.to_period('M'))["Total Revenue"].sum()

        monthly.plot(kind="line", marker="o")
        plt.title("Monthly Sales Revenue")
        plt.ylabel("Revenue")
        plt.show()

    def visualize_revenue_pie(self):
        merged = pd.merge(self.sales_df, self.inventory_df, on="Title")
        revenue_by_genre = merged.groupby("Genre")["Total Revenue"].sum()

        revenue_by_genre.plot(kind="pie", autopct="%1.1f%%")
        plt.title("Revenue Share by Genre")
        plt.ylabel("")
        plt.show()

    def visualize_price_sales_correlation(self):
        merged = pd.merge(self.sales_df, self.inventory_df, on="Title")
        corr = merged[["Price", "Quantity Sold"]].corr()

        sns.heatmap(corr, annot=True, cmap="coolwarm")
        plt.title("Price vs Sales Correlation")
        plt.show()

# ---------------------------------------------
# MAIN MENU
# ---------------------------------------------
def main():
    store = Bookstore()

    while True:
        print("\n========== 📚 BOOKSTORE SYSTEM ==========")
        print("1. Add Book")
        print("2. Update Inventory")
        print("3. Record Sale")
        print("4. Generate Report")
        print("5. Visualize Sales by Genre")
        print("6. Visualize Monthly Sales")
        print("7. Revenue Pie Chart (Genre-wise)")
        print("8. Price-Sales Correlation Heatmap")
        print("9. Exit")

        choice = input("Enter choice: ")

        if choice == '1':
            t = input("Title: ")
            a = input("Author: ")
            g = input("Genre: ")
            p = float(input("Price: "))
            q = int(input("Quantity: "))
            store.add_book(t, a, g, p, q)

        elif choice == '2':
            t = input("Title: ")
            q = int(input("New Quantity: "))
            store.update_inventory(t, q)

        elif choice == '3':
            t = input("Title: ")
            q = int(input("Quantity Sold: "))
            store.record_sale(t, q)

        elif choice == '4':
            store.generate_report()

        elif choice == '5':
            store.visualize_sales_by_genre()

        elif choice == '6':
            store.visualize_monthly_sales()

        elif choice == '7':
            store.visualize_revenue_pie()

        elif choice == '8':
            store.visualize_price_sales_correlation()

        elif choice == '9':
            print("Exiting program...")
            break

        else:
            print(" Invalid choice. Try again.")


if __name__ == "__main__":
    main()


# In[ ]:




